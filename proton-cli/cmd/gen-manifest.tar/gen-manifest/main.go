package main

import (
	"archive/tar"
	"compress/gzip"
	"context"
	"errors"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strings"

	"github.com/spf13/cobra"
	meta "k8s.io/apimachinery/pkg/apis/meta/v1"
	"oras.land/oras-go/v2"
	"oras.land/oras-go/v2/content/oci"
	"oras.land/oras-go/v2/registry/remote"
	"oras.land/oras-go/v2/registry/remote/auth"
	"oras.land/oras-go/v2/registry/remote/retry"
	"sigs.k8s.io/yaml"
)

type Manifest struct {
	meta.TypeMeta
	meta.ObjectMeta

	Spec ManifestSpec `json:"spec,omitzero"`
}

type ManifestSpec struct {
	Architecture string `json:"architecture,omitzero"`

	Repository string `json:"repository,omitzero"`

	Components []Component `json:"components,omitzero"`

	Images []Image

	Charts []Chart

	Binaries []Binary

	RPMs []RPM
}

type Component struct {
	Name string `json:"name,omitzero"`

	Version string `json:"version,omitzero"`
}

type Binary struct {
	Name string `json:"name,omitzero"`

	Digest Digest `json:"digest,omitzero"`

	Source string `json:"source,omitzero"`

	Format string `json:"format,omitzero"`

	Path string `json:"path,omitzero"`
}

type Chart struct {
	Name string `json:"name,omitzero"`

	Digest Digest `json:"digest,omitzero"`

	Source string `json:"source,omitzero"`
}

type Image struct {
	Repository string `json:"name,omitzero"`

	Tag string `json:"tag,omitzero"`

	// Digest Digest `json:"digest,omitzero"`

	Source string `json:"source,omitzero"`
}

type RPM struct {
	Name string `json:"name,omitzero"`

	Digest Digest `json:"digest,omitzero"`

	Source string `json:"source,omitzero"`
}

type Digest string

func (d Digest) String() string {
	a, h, found := strings.Cut(string(d), ":")
	if !found {
		return a
	}

	if len(h) > 16 {
		h = h[:16]
	}

	return a + ":" + h
}

func main() {
	cmd := &cobra.Command{
		Use:  "gen-manifest",
		Args: cobra.ExactArgs(1),
		RunE: func(cmd *cobra.Command, args []string) error {
			return generate(args[0], cmd.OutOrStdout())
		},
	}

	if err := cmd.Execute(); err != nil {
		os.Exit(1)
	}
}

func generate(p string, w io.Writer) error {
	y, err := os.ReadFile(p)
	if err != nil {
		return err
	}

	m := new(Manifest)
	if err := yaml.Unmarshal(y, m); err != nil {
		return err
	}

	// download binaries
	if err := os.MkdirAll("build/bin", 0755); err != nil {
		return err
	}
	for _, b := range m.Spec.Binaries {
		log.Println("Download binary", b.Name)
		if err := downloadBinary(&b); err != nil {
			return err
		}
	}

	// pull charts
	if err := os.MkdirAll("build/charts", 0755); err != nil {
		return err
	}
	for _, item := range m.Spec.Charts {
		log.Println("Download chart", item.Name)
		if err := downloadChart(&item); err != nil {
			return err
		}
	}

	// pull images
	if err := os.MkdirAll("build/images", 0755); err != nil {
		return err
	}
	for _, item := range m.Spec.Images {
		log.Println("Download image", item.Repository)
		if err := downloadImage(&item); err != nil {
			return err
		}
	}

	// package tarball
	if err := packageTarball(); err != nil {
		return err
	}

	return nil
}

func downloadBinary(b *Binary) error {
	path := filepath.Join("build/bin", b.Name)

	// Return if already exists
	// if _, err := os.Stat(path); err == nil {
	// 	// TODO: Check hash
	// 	return nil
	// }

	r, err := openHTTPFile(b.Source)
	if err != nil {
		return err
	}
	defer r.Close()

	var rr io.Reader
	switch b.Format {
	case "":
		rr = r
	case "tar+gzip":
		gr, err := gzip.NewReader(r)
		if err != nil {
			return err
		}

		tr := tar.NewReader(gr)
		for {
			h, err := tr.Next()
			if errors.Is(err, io.EOF) {
				break
			}
			if err != nil {
				return err
			}

			if h.Name != b.Path {
				continue
			}

			rr = tr
			break
		}
	default:
		return fmt.Errorf("invalid format %q", b.Format)
	}

	f, err := os.Create(path)
	if err != nil {
		return err
	}
	defer f.Close()

	if err := f.Chmod(0755); err != nil {
		return err
	}

	if _, err := io.Copy(f, rr); err != nil {
		return err
	}

	// TODO: checksum

	return nil
}

func downloadChart(c *Chart) error {
	r, err := openHTTPFile(c.Source)
	if err != nil {
		return err
	}
	defer r.Close()

	f, err := os.Create(filepath.Join("build/charts", c.Name))
	if err != nil {
		return err
	}
	defer f.Close()

	if _, err := io.Copy(f, r); err != nil {
		return err
	}

	return nil
}

func downloadImage(i *Image) error {
	ctx := context.Background()
	// 1. Connect to a remote repository with token authentication
	repo, err := remote.NewRepository(i.Source)
	if err != nil {
		return err
	}
	// Note: The below code can be omitted if authentication is not required.
	repo.Client = &auth.Client{
		Client: retry.DefaultClient,
		Cache:  auth.NewCache(),
		// Credential: auth.StaticCredential(repo.Reference.Registry, auth.Credential{
		// 	Username: "hello",
		// 	Password: "world",
		// }),
	}
	repo.PlainHTTP = true

	// 2. Show the tags in the repository
	// err = repo.Tags(ctx, "", func(tags []string) error {
	// 	for _, tag := range tags {
	// 		fmt.Println(tag)
	// 	}
	// 	return nil
	// })
	// if err != nil {
	// 	return err
	// }

	ociTarget, err := oci.New("build/images")

	// 7. Copy the artifact to local OCI layout directory with a tag "quickstartOCI"

	if _, err = oras.Copy(ctx, repo, i.Tag, ociTarget, i.Repository+":"+i.Tag, oras.DefaultCopyOptions); err != nil {
		return err
	}

	return nil
}

func openHTTPFile(url string) (io.ReadCloser, error) {
	resp, err := http.Get(url)
	if err != nil {
		return nil, err
	}

	if resp.StatusCode != http.StatusOK {
		body, err := io.ReadAll(resp.Body)
		if err != nil {
			return nil, fmt.Errorf("status: %s, read response body fail: %w", resp.Status, err)
		}

		return nil, fmt.Errorf("status: %s, body: %s", resp.Status, body)
	}

	return resp.Body, nil
}

func packageTarball() error {
	f, err := os.Create("proton-offline-package.tar")
	if err != nil {
		return err
	}
	defer f.Close()

	tw := tar.NewWriter(f)
	defer tw.Close()

	for _, p := range []string{
		"build",
		"install.sh",
	} {
		if err := tw.AddFS(os.DirFS(p)); err != nil {
			return err
		}
	}

	if err := tw.AddFS(os.DirFS("build")); err != nil {
		return err
	}

	return nil
}
